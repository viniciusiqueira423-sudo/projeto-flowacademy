<?php

// INÍCIO - DOCUMENTACAO DE ESTUDO
// Proposito do arquivo: Mostra detalhes consolidados de um aluno, incluindo matriculas, notas, frequencias e pagamentos.
// Fluxo geral: carregar dependencias, validar permissao, processar entradas, consultar o banco e renderizar a tela.
// Observacao: foram adicionados somente comentarios; nenhuma regra de negocio foi alterada.

// INÍCIO - Carrega dependencias compartilhadas antes de executar esta pagina.
require_once __DIR__ . '/../includes/funcoes.php';
// VALIDAÇÃO - Garante que somente perfis autorizados acessem este arquivo.
exigirPerfil(['admin', 'coordenacao', 'administrativo'], '../');

// PROCESSAMENTO - Variavel $base guarda estado ou dados usados nas proximas etapas.
$base = '../';
// PROCESSAMENTO - Variavel $titulo guarda estado ou dados usados nas proximas etapas.
$titulo = 'Ficha do Aluno';
// PROCESSAMENTO - Variavel $ativo guarda estado ou dados usados nas proximas etapas.
$ativo = 'alunos';

// PROCESSAMENTO - Variavel $idAluno guarda estado ou dados usados nas proximas etapas.
$idAluno = (int) getValor('id');
// CONSULTA AO BANCO - Busca um unico registro para validar ou preencher a tela.
$aluno = buscarUm(
    'SELECT a.*, u.nome, u.email, u.status AS acesso
     FROM alunos a JOIN usuarios u ON u.id_usuario = a.id_usuario
     WHERE a.id_aluno = :id',
    [':id' => $idAluno]
);

// VALIDAÇÃO - Condicao que direciona o fluxo conforme dados, perfil ou estado atual.
if (!$aluno) {
    // RETORNO - Prepara mensagem temporaria para informar o resultado ao usuario.
    flash('danger', 'Aluno nao encontrado.');
    // RETORNO - Redireciona apos concluir o fluxo e evita reenvio de formulario.
    redirecionar('alunos.php');
}

// CONSULTA AO BANCO - Busca uma colecao de registros usando SQL preparado.
$matriculas = buscarTodos(
    'SELECT m.*, t.codigo_turma, c.nome AS curso
     FROM matriculas m
     JOIN turmas t ON t.id_turma = m.id_turma
     JOIN cursos c ON c.id_curso = t.id_curso
     WHERE m.id_aluno = :id
     ORDER BY m.id_matricula DESC',
    [':id' => $idAluno]
);

// CONSULTA AO BANCO - Busca uma colecao de registros usando SQL preparado.
$notas = buscarTodos(
    'SELECT d.nome AS disciplina, n.prova_1, n.prova_2, n.trabalho, n.comportamental, n.media_uc, n.status
     FROM notas n
     JOIN matriculas m ON m.id_matricula = n.id_matricula
     WHERE m.id_aluno = :id
     ORDER BY d.nome',
    [':id' => $idAluno]
);

// CONSULTA AO BANCO - Busca uma colecao de registros usando SQL preparado.
$pagamentos = buscarTodos(
    'SELECT * FROM pagamentos WHERE id_aluno = :id ORDER BY vencimento DESC',
    [':id' => $idAluno]
);

// RETORNO - A partir daqui a pagina comeca a renderizar o layout HTML comum.
require __DIR__ . '/../includes/header.php';
?>

<!-- INÍCIO - Secao visual que agrupa informacoes ou formulario desta parte da pagina. -->
<section class="page-heading"><div><span class="eyebrow">Alunos</span><h1><?= e($aluno['nome']) ?></h1><p>Ficha individual, historico de notas e financeiro do aluno.</p></div></section>

<div class="grid two">
<!-- INÍCIO - Secao visual que agrupa informacoes ou formulario desta parte da pagina. -->
  <section class="panel">
    <div class="panel-header"><h2>Dados pessoais</h2></div>
    <div class="panel-body info-list">
      <div><span>Nome</span><strong><?= e($aluno['nome']) ?></strong></div>
      <div><span>E-mail</span><strong><?= e($aluno['email']) ?></strong></div>
      <div><span>Matricula</span><strong><?= e($aluno['matricula']) ?></strong></div>
      <div><span>CPF</span><strong><?= e($aluno['cpf']) ?></strong></div>
      <div><span>Telefone</span><strong><?= e($aluno['telefone']) ?></strong></div>
      <div><span>Status</span><?= badge($aluno['status_academico']) ?></div>
    </div>
  </section>

<!-- INÍCIO - Secao visual que agrupa informacoes ou formulario desta parte da pagina. -->
  <section class="panel">
    <div class="panel-header"><h2>Matriculas</h2></div>
    <div class="table-wrap">
<!-- RETORNO - Tabela apresenta ao usuario os dados consultados no banco. -->
      <table><thead><tr><th>Turma</th><th>Curso</th><th>Status</th></tr></thead><tbody>
<!-- VALIDAÇÃO - Bloco condicional da camada de apresentacao. -->
        <?php if (empty($matriculas)): ?><tr><td colspan="3">Nenhuma matricula encontrada.</td></tr><?php endif; ?>
<!-- PROCESSAMENTO - Repeticao usada para renderizar cada item retornado pelas consultas. -->
        <?php foreach ($matriculas as $matricula): ?>
          <tr><td><?= e($matricula['codigo_turma']) ?></td><td><?= e($matricula['curso']) ?></td><td><?= badge($matricula['status']) ?></td></tr>
        <?php endforeach; ?>
      </tbody></table>
    </div>
  </section>
</div>

<!-- INÍCIO - Secao visual que agrupa informacoes ou formulario desta parte da pagina. -->
<section class="panel">
  <div class="panel-header"><h2>Boletim</h2></div>
  <div class="table-wrap">
<!-- RETORNO - Tabela apresenta ao usuario os dados consultados no banco. -->
    <table><thead><tr><th>UC</th><th>P1</th><th>P2</th><th>Trabalho</th><th>Comp.</th><th>Media</th><th>Status</th></tr></thead><tbody>
<!-- VALIDAÇÃO - Bloco condicional da camada de apresentacao. -->
      <?php if (empty($notas)): ?><tr><td colspan="7">Nenhuma nota encontrada.</td></tr><?php endif; ?>
<!-- PROCESSAMENTO - Repeticao usada para renderizar cada item retornado pelas consultas. -->
      <?php foreach ($notas as $nota): ?>
        <tr><td><?= e($nota['disciplina']) ?></td><td><?= e($nota['prova_1']) ?></td><td><?= e($nota['prova_2']) ?></td><td><?= e($nota['trabalho']) ?></td><td><?= e($nota['comportamental']) ?></td><td><?= e($nota['media_uc']) ?></td><td><?= badge($nota['status']) ?></td></tr>
      <?php endforeach; ?>
    </tbody></table>
  </div>
</section>

<!-- INÍCIO - Secao visual que agrupa informacoes ou formulario desta parte da pagina. -->
<section class="panel">
  <div class="panel-header"><h2>Pagamentos</h2></div>
  <div class="table-wrap">
<!-- RETORNO - Tabela apresenta ao usuario os dados consultados no banco. -->
    <table><thead><tr><th>Valor</th><th>Vencimento</th><th>Status</th></tr></thead><tbody>
<!-- VALIDAÇÃO - Bloco condicional da camada de apresentacao. -->
      <?php if (empty($pagamentos)): ?><tr><td colspan="3">Nenhum pagamento encontrado.</td></tr><?php endif; ?>
<!-- PROCESSAMENTO - Repeticao usada para renderizar cada item retornado pelas consultas. -->
      <?php foreach ($pagamentos as $pagamento): ?>
        <tr><td><?= e(dinheiro($pagamento['valor'])) ?></td><td><?= e(dataBr($pagamento['vencimento'])) ?></td><td><?= badge($pagamento['status']) ?></td></tr>
      <?php endforeach; ?>
    </tbody></table>
  </div>
</section>

<div class="actions"><a class="btn ghost" href="alunos.php">Voltar</a></div>

<?php require __DIR__ . '/../includes/footer.php'; ?>

<!-- FIM - Final do arquivo documentado para estudo. -->